import {
  users,
  doctors,
  appointments,
  messages,
  reviews,
  medicalDocuments,
  doctorAvailability,
  type User,
  type UpsertUser,
  type Doctor,
  type InsertDoctor,
  type Appointment,
  type InsertAppointment,
  type Message,
  type InsertMessage,
  type Review,
  type InsertReview,
  type MedicalDocument,
  type InsertMedicalDocument,
  type DoctorAvailability,
  type InsertDoctorAvailability,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, like, ilike, desc, or } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUser(id: string, updateData: Partial<User>): Promise<User>;

  // Doctor operations
  getDoctors(filters?: { specialty?: string; search?: string }): Promise<Doctor[]>;
  getDoctorById(id: number): Promise<Doctor | undefined>;
  createDoctor(doctor: InsertDoctor): Promise<Doctor>;
  getDoctorReviews(doctorId: number): Promise<Review[]>;
  getDoctorAvailability(doctorId: number, date?: string): Promise<DoctorAvailability[]>;

  // Appointment operations
  getPatientAppointments(patientId: string, status?: string): Promise<Appointment[]>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, patientId: string, updateData: Partial<Appointment>): Promise<Appointment | undefined>;
  getAppointmentById(id: number, patientId: string): Promise<Appointment | undefined>;
  getPatientConsultations(patientId: string): Promise<Appointment[]>;

  // Message operations
  getPatientConversations(patientId: string): Promise<any[]>;
  getConversationMessages(conversationId: string, userId: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;

  // Review operations
  createReview(review: InsertReview): Promise<Review>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUser(id: string, updateData: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Doctor operations
  async getDoctors(filters?: { specialty?: string; search?: string }): Promise<Doctor[]> {
    let whereConditions = eq(doctors.isAvailable, true);

    if (filters?.specialty) {
      whereConditions = and(whereConditions, ilike(doctors.specialty, `%${filters.specialty}%`))!;
    }

    if (filters?.search) {
      whereConditions = and(
        whereConditions,
        or(
          ilike(doctors.firstName, `%${filters.search}%`),
          ilike(doctors.lastName, `%${filters.search}%`),
          ilike(doctors.specialty, `%${filters.search}%`)
        )
      )!;
    }

    return await db
      .select()
      .from(doctors)
      .where(whereConditions)
      .orderBy(desc(doctors.rating));
  }

  async getDoctorById(id: number): Promise<Doctor | undefined> {
    const [doctor] = await db.select().from(doctors).where(eq(doctors.id, id));
    return doctor;
  }

  async createDoctor(doctor: InsertDoctor): Promise<Doctor> {
    const [newDoctor] = await db.insert(doctors).values(doctor).returning();
    return newDoctor;
  }

  async getDoctorReviews(doctorId: number): Promise<Review[]> {
    return await db
      .select()
      .from(reviews)
      .where(eq(reviews.doctorId, doctorId))
      .orderBy(desc(reviews.createdAt));
  }

  async getDoctorAvailability(doctorId: number, date?: string): Promise<DoctorAvailability[]> {
    return await db
      .select()
      .from(doctorAvailability)
      .where(and(
        eq(doctorAvailability.doctorId, doctorId),
        eq(doctorAvailability.isAvailable, true)
      ));
  }

  // Appointment operations
  async getPatientAppointments(patientId: string, status?: string): Promise<Appointment[]> {
    let whereConditions = eq(appointments.patientId, patientId);

    if (status && status !== 'upcoming') {
      if (status === 'past') {
        whereConditions = and(whereConditions, eq(appointments.status, 'completed'))!;
      } else {
        whereConditions = and(whereConditions, eq(appointments.status, status))!;
      }
    } else if (status === 'upcoming') {
      whereConditions = and(
        whereConditions,
        or(
          eq(appointments.status, 'pending'),
          eq(appointments.status, 'confirmed')
        )
      )!;
    }

    return await db
      .select()
      .from(appointments)
      .where(whereConditions)
      .orderBy(desc(appointments.appointmentDate));
  }

  async createAppointment(appointment: InsertAppointment): Promise<Appointment> {
    const [newAppointment] = await db.insert(appointments).values(appointment).returning();
    return newAppointment;
  }

  async updateAppointment(id: number, patientId: string, updateData: Partial<Appointment>): Promise<Appointment | undefined> {
    const [appointment] = await db
      .update(appointments)
      .set({ ...updateData, updatedAt: new Date() })
      .where(and(
        eq(appointments.id, id),
        eq(appointments.patientId, patientId)
      ))
      .returning();
    return appointment;
  }

  async getAppointmentById(id: number, patientId: string): Promise<Appointment | undefined> {
    const [appointment] = await db
      .select()
      .from(appointments)
      .where(and(
        eq(appointments.id, id),
        eq(appointments.patientId, patientId)
      ));
    return appointment;
  }

  async getPatientConsultations(patientId: string): Promise<Appointment[]> {
    return await db
      .select()
      .from(appointments)
      .where(and(
        eq(appointments.patientId, patientId),
        eq(appointments.status, 'completed')
      ))
      .orderBy(desc(appointments.appointmentDate));
  }

  // Message operations
  async getPatientConversations(patientId: string): Promise<any[]> {
    // Return empty array for now - would need to implement conversation logic
    return [];
  }

  async getConversationMessages(conversationId: string, userId: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(messages.createdAt);
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages).values(message).returning();
    return newMessage;
  }

  // Review operations
  async createReview(review: InsertReview): Promise<Review> {
    const [newReview] = await db.insert(reviews).values(review).returning();
    return newReview;
  }
}

export const storage = new DatabaseStorage();