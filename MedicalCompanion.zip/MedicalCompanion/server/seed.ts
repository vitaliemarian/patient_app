import { db } from "./db";
import { doctors } from "@shared/schema";

async function seed() {
  try {
    // Insert sample doctors
    await db.insert(doctors).values([
      {
        firstName: 'Elena',
        lastName: 'Stanciu',
        email: 'elena.stanciu@medpark.md',
        specialty: 'Dermatology',
        licenseNumber: 'MD-DERM-001',
        yearsExperience: 12,
        education: 'MD from University of Medicine and Pharmacy, Dermatology Residency at Johns Hopkins',
        about: 'Specialized in skin conditions, allergic reactions, and cosmetic dermatology with over 12 years of experience.',
        profileImageUrl: 'https://images.unsplash.com/photo-1594824388191-c3076b8ef3e3?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300',
        rating: '4.95',
        reviewCount: 801,
        consultationFee: '350.00',
        location: 'Medpark, Chișinău',
        distance: '2.3',
      },
      {
        firstName: 'Sarah',
        lastName: 'Mitchell',
        email: 'sarah.mitchell@clinic.md',
        specialty: 'Cardiology',
        licenseNumber: 'MD-CARD-002',
        yearsExperience: 15,
        education: 'MD from Harvard Medical School, Cardiology Fellowship at Mayo Clinic',
        about: 'Board-certified cardiologist specializing in preventive cardiology and heart disease management.',
        profileImageUrl: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300',
        rating: '4.88',
        reviewCount: 567,
        consultationFee: '400.00',
        location: 'City Medical Center',
        distance: '1.8',
      },
      {
        firstName: 'Michael',
        lastName: 'Thompson',
        email: 'michael.thompson@pediatrics.md',
        specialty: 'Pediatrics',
        licenseNumber: 'MD-PED-003',
        yearsExperience: 8,
        education: 'MD from Stanford University, Pediatrics Residency at Children Hospital',
        about: 'Pediatric specialist focusing on child development, vaccinations, and adolescent health.',
        profileImageUrl: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300',
        rating: '4.92',
        reviewCount: 423,
        consultationFee: '280.00',
        location: 'Children Medical Center',
        distance: '3.1',
      },
      {
        firstName: 'Alexandra',
        lastName: 'Popescu',
        email: 'alexandra.popescu@orthopedics.md',
        specialty: 'Orthopedics',
        licenseNumber: 'MD-ORTH-004',
        yearsExperience: 18,
        education: 'MD from University of Bucharest, Orthopedic Surgery Fellowship at Hospital for Special Surgery',
        about: 'Orthopedic surgeon specializing in joint replacement, sports injuries, and trauma surgery.',
        profileImageUrl: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300',
        rating: '4.97',
        reviewCount: 289,
        consultationFee: '450.00',
        location: 'Orthopedic Institute',
        distance: '4.2',
      },
      {
        firstName: 'David',
        lastName: 'Rodriguez',
        email: 'david.rodriguez@neurology.md',
        specialty: 'Neurology',
        licenseNumber: 'MD-NEU-005',
        yearsExperience: 14,
        education: 'MD from Johns Hopkins, Neurology Residency at UCLA Medical Center',
        about: 'Neurologist specializing in headaches, epilepsy, and movement disorders.',
        profileImageUrl: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300',
        rating: '4.85',
        reviewCount: 356,
        consultationFee: '380.00',
        location: 'Neuroscience Center',
        distance: '2.7',
      }
    ]).onConflictDoNothing();

    console.log('Database seeded successfully');
  } catch (error) {
    console.error('Error seeding database:', error);
  }
}

seed();