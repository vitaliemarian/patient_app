import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Calendar, Clock, Download } from "lucide-react";
import { useLocation } from "wouter";
import { Appointment } from "@shared/schema";

interface ConsultationCardProps {
  consultation: Appointment & {
    doctor?: {
      firstName: string;
      lastName: string;
      specialty: string;
      profileImageUrl?: string;
    };
  };
}

export default function ConsultationCard({ consultation }: ConsultationCardProps) {
  const [, setLocation] = useLocation();

  const handleViewReport = () => {
    // For demo purposes, show alert
    alert("View full consultation report");
  };

  const handleDownload = () => {
    // For demo purposes, show alert
    alert("Download prescription");
  };

  const handleFollowUp = () => {
    setLocation(`/doctors/${consultation.doctorId}/book`);
  };

  return (
    <Card className="shadow-sm border border-gray-100">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-trust-green rounded-full" />
            <span className="text-sm font-medium text-trust-green">Completed</span>
          </div>
          <span className="text-xs text-gray-500">ID: #{consultation.id}</span>
        </div>
        
        <div className="flex space-x-4 mb-4">
          <img 
            src={consultation.doctor?.profileImageUrl || "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200"} 
            alt={`Dr. ${consultation.doctor?.firstName} ${consultation.doctor?.lastName}`} 
            className="w-12 h-12 rounded-lg object-cover" 
          />
          <div className="flex-1">
            <h3 className="font-medium text-gray-900">
              Dr. {consultation.doctor?.firstName} {consultation.doctor?.lastName}
            </h3>
            <p className="text-sm text-medical-gray">{consultation.doctor?.specialty}</p>
            <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
              <div className="flex items-center">
                <Calendar className="h-3 w-3 mr-1" />
                <span>{new Date(consultation.appointmentDate).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center">
                <Clock className="h-3 w-3 mr-1" />
                <span>{consultation.type === 'video' ? 'Video Call' : 'In-Person'}</span>
              </div>
            </div>
          </div>
        </div>

        {consultation.diagnosis && (
          <div className="bg-gray-50 rounded-xl p-3 mb-4">
            <p className="text-sm font-medium text-gray-900 mb-1">Diagnosis</p>
            <p className="text-sm text-gray-600">{consultation.diagnosis}</p>
          </div>
        )}

        {consultation.treatment && (
          <div className="bg-gray-50 rounded-xl p-3 mb-4">
            <p className="text-sm font-medium text-gray-900 mb-1">Treatment</p>
            <p className="text-sm text-gray-600">{consultation.treatment}</p>
          </div>
        )}

        <div className="flex space-x-2">
          <Button 
            onClick={handleViewReport}
            className="flex-1 bg-medical-blue text-white hover:bg-medical-deep"
          >
            View Full Report
          </Button>
          <Button 
            onClick={handleDownload}
            variant="outline"
            size="icon"
          >
            <Download className="h-4 w-4" />
          </Button>
          <Button 
            onClick={handleFollowUp}
            className="bg-trust-green text-white hover:bg-green-600"
          >
            Follow-up
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
