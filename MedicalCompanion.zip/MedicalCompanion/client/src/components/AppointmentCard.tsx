import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Calendar, MapPin, MessageCircle } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Appointment } from "@shared/schema";

interface AppointmentCardProps {
  appointment: Appointment & {
    doctor?: {
      firstName: string;
      lastName: string;
      specialty: string;
      profileImageUrl?: string;
    };
  };
}

export default function AppointmentCard({ appointment }: AppointmentCardProps) {
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const updateAppointment = useMutation({
    mutationFn: async (status: string) => {
      const response = await apiRequest('PATCH', `/api/appointments/${appointment.id}`, {
        status,
      });
      return response.json();
    },
    onSuccess: (_, status) => {
      toast({
        title: "Appointment Updated",
        description: `Appointment has been ${status}.`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleContactDoctor = () => {
    // Create conversation ID based on appointment
    const conversationId = `appointment-${appointment.id}`;
    setLocation(`/chat/${conversationId}`);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'text-trust-green';
      case 'pending':
        return 'text-yellow-600';
      case 'completed':
        return 'text-blue-600';
      case 'cancelled':
        return 'text-red-600';
      default:
        return 'text-gray-600';
    }
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-trust-green';
      case 'pending':
        return 'bg-yellow-400';
      case 'completed':
        return 'bg-blue-600';
      case 'cancelled':
        return 'bg-red-600';
      default:
        return 'bg-gray-600';
    }
  };

  return (
    <Card className="shadow-sm border border-gray-100">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${getStatusBadgeColor(appointment.status)}`} />
            <span className={`text-sm font-medium ${getStatusColor(appointment.status)}`}>
              {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
            </span>
          </div>
          <span className="text-xs text-gray-500">ID: #{appointment.id}</span>
        </div>
        
        <div className="flex space-x-4">
          <img 
            src={appointment.doctor?.profileImageUrl || "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200"} 
            alt={`Dr. ${appointment.doctor?.firstName} ${appointment.doctor?.lastName}`} 
            className="w-12 h-12 rounded-lg object-cover" 
          />
          <div className="flex-1">
            <h3 className="font-medium text-gray-900">
              Dr. {appointment.doctor?.firstName} {appointment.doctor?.lastName}
            </h3>
            <p className="text-sm text-medical-gray">{appointment.doctor?.specialty}</p>
            <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
              <div className="flex items-center">
                <Calendar className="h-3 w-3 mr-1" />
                <span>
                  {new Date(appointment.appointmentDate).toLocaleDateString()}, {' '}
                  {new Date(appointment.appointmentDate).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </span>
              </div>
              <div className="flex items-center">
                <MapPin className="h-3 w-3 mr-1" />
                <span>{appointment.type === 'in-person' ? 'In-Person' : 'Video Call'}</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm font-medium text-gray-900">${appointment.totalCost}</p>
          </div>
        </div>
        
        <div className="flex space-x-2 mt-4">
          {appointment.status === 'pending' || appointment.status === 'confirmed' ? (
            <>
              <Button 
                variant="outline"
                onClick={() => updateAppointment.mutate('cancelled')}
                disabled={updateAppointment.isPending}
                className="flex-1 text-gray-700 hover:bg-gray-100"
              >
                {appointment.status === 'pending' ? 'Cancel' : 'Reschedule'}
              </Button>
              <Button 
                variant="outline"
                onClick={() => updateAppointment.mutate('cancelled')}
                disabled={updateAppointment.isPending}
                className="flex-1 bg-red-50 text-red-600 hover:bg-red-100"
              >
                Cancel
              </Button>
            </>
          ) : (
            <Button 
              variant="outline"
              className="flex-1 text-gray-700 hover:bg-gray-100"
            >
              View Details
            </Button>
          )}
          <Button 
            onClick={handleContactDoctor}
            className="bg-medical-blue text-white hover:bg-medical-deep"
          >
            <MessageCircle className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
