import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";

interface MessageCardProps {
  conversation: {
    conversationId: string;
    doctorName: string;
    doctorSpecialty: string;
    doctorImageUrl?: string;
    lastMessage: string;
    lastMessageTime: string;
    unreadCount: number;
  };
}

export default function MessageCard({ conversation }: MessageCardProps) {
  const [, setLocation] = useLocation();

  const handleClick = () => {
    setLocation(`/chat/${conversation.conversationId}`);
  };

  return (
    <Card 
      className="shadow-sm border border-gray-100 hover:shadow-md transition-shadow cursor-pointer"
      onClick={handleClick}
    >
      <CardContent className="p-4">
        <div className="flex space-x-4">
          <img 
            src={conversation.doctorImageUrl || "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200"} 
            alt={conversation.doctorName} 
            className="w-12 h-12 rounded-lg object-cover" 
          />
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <h3 className="font-medium text-gray-900">{conversation.doctorName}</h3>
              <span className="text-xs text-gray-500">{conversation.lastMessageTime}</span>
            </div>
            <p className="text-sm text-medical-gray mb-2">{conversation.doctorSpecialty}</p>
            <p className="text-sm text-gray-600 truncate">{conversation.lastMessage}</p>
          </div>
          <div className="flex flex-col items-center justify-between">
            {conversation.unreadCount > 0 && (
              <div className="w-2 h-2 bg-medical-blue rounded-full" />
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
