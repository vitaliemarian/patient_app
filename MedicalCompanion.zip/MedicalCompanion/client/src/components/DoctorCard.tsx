import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Star, MapPin, Clock } from "lucide-react";
import { Doctor } from "@shared/schema";

interface DoctorCardProps {
  doctor: Doctor;
}

export default function DoctorCard({ doctor }: DoctorCardProps) {
  const [, setLocation] = useLocation();

  const handleViewProfile = () => {
    setLocation(`/doctors/${doctor.id}`);
  };

  const handleBookNow = () => {
    setLocation(`/doctors/${doctor.id}/book`);
  };

  return (
    <Card className="shadow-lg border-0 hover:shadow-xl transition-all duration-300 hover:scale-[1.02] bg-white rounded-2xl">
      <CardContent className="p-5">
        <div className="flex space-x-4">
          <div className="relative">
            <img 
              src={doctor.profileImageUrl || "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200"} 
              alt={`Dr. ${doctor.firstName} ${doctor.lastName}`} 
              className="w-18 h-18 rounded-2xl object-cover shadow-md" 
            />
            <div className="absolute -top-1 -right-1 w-6 h-6 bg-medical-success rounded-full border-2 border-white"></div>
          </div>
          <div className="flex-1">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-bold medical-text text-lg">
                  Dr. {doctor.firstName} {doctor.lastName}
                </h3>
                <p className="text-sm medical-text-light font-medium">{doctor.specialty}</p>
                <div className="flex items-center space-x-2 mt-2">
                  <div className="flex items-center bg-yellow-50 px-2 py-1 rounded-lg">
                    <Star className="h-3 w-3 text-yellow-500 fill-current" />
                    <span className="text-sm font-semibold text-yellow-700 ml-1">
                      {doctor.rating}
                    </span>
                    <span className="text-xs medical-text-light ml-1">
                      ({doctor.reviewCount})
                    </span>
                  </div>
                </div>
                <div className="flex items-center space-x-4 mt-3">
                  <div className="flex items-center text-xs medical-text-light">
                    <MapPin className="h-3 w-3 mr-1" />
                    <span>{doctor.distance}km away</span>
                  </div>
                  <div className="flex items-center text-xs medical-success">
                    <Clock className="h-3 w-3 mr-1" />
                    <span className="font-medium">Available today</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xl font-bold medical-text">
                  ${doctor.consultationFee}
                </p>
                <p className="text-xs medical-text-light">Consultation</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 mt-4">
              <Button 
                onClick={handleViewProfile}
                variant="outline"
                className="flex-1 border-2 border-medical-blue text-medical-blue py-3 px-4 rounded-xl text-sm font-semibold hover:bg-medical-blue hover:text-white transition-all duration-200"
              >
                View Profile
              </Button>
              <Button 
                onClick={handleBookNow}
                className="bg-gradient-to-r from-medical-success to-medical-success/90 text-white py-3 px-6 rounded-xl text-sm font-semibold hover:shadow-lg transition-all duration-200 transform hover:scale-[1.02]"
              >
                Book Now
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
