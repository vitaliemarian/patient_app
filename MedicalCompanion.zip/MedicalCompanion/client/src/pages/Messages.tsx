import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import MessageCard from "@/components/MessageCard";
import BottomNav from "@/components/BottomNav";

interface Conversation {
  conversationId: string;
  doctorName: string;
  doctorSpecialty: string;
  doctorImageUrl?: string;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
}

export default function Messages() {
  const { data: conversations = [], isLoading } = useQuery<Conversation[]>({
    queryKey: ['/api/conversations'],
  });

  return (
    <div className="pb-20">
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Messages</h2>
          <Button
            variant="ghost"
            size="icon"
            className="w-10 h-10 bg-gray-100 rounded-full"
          >
            <Search className="h-5 w-5 text-gray-600" />
          </Button>
        </div>

        {/* Messages List */}
        {isLoading ? (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="bg-gray-200 rounded-2xl h-20 animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {conversations.map((conversation) => (
              <MessageCard key={conversation.conversationId} conversation={conversation} />
            ))}
            
            {conversations.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-500">No conversations yet.</p>
                <p className="text-sm text-gray-400 mt-2">
                  Messages with your doctors will appear here.
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}
