import { useQuery } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Heart, Share, Star, MapPin, Calendar, Clock } from "lucide-react";
import { Doctor, Review } from "@shared/schema";

export default function DoctorProfile() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const doctorId = parseInt(id!);

  const { data: doctor, isLoading: doctorLoading } = useQuery<Doctor>({
    queryKey: [`/api/doctors/${doctorId}`],
  });

  const { data: reviews = [] } = useQuery<Review[]>({
    queryKey: [`/api/doctors/${doctorId}/reviews`],
  });

  const handleBack = () => {
    setLocation('/doctors');
  };

  const handleBookAppointment = () => {
    setLocation(`/doctors/${doctorId}/book`);
  };

  if (doctorLoading || !doctor) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleBack}
            className="w-10 h-10 bg-white/80 rounded-full shadow-sm"
          >
            <ArrowLeft className="h-5 w-5 text-gray-600" />
          </Button>
          <div className="flex space-x-2">
            <div className="w-10 h-10 bg-gray-200 rounded-full animate-pulse" />
            <div className="w-10 h-10 bg-gray-200 rounded-full animate-pulse" />
          </div>
        </div>
        <div className="space-y-4">
          <div className="w-24 h-24 bg-gray-200 rounded-2xl mx-auto animate-pulse" />
          <div className="h-6 bg-gray-200 rounded animate-pulse" />
          <div className="h-4 bg-gray-200 rounded animate-pulse" />
        </div>
      </div>
    );
  }

  return (
    <div className="relative">
      {/* Header */}
      <div className="relative bg-gradient-to-br from-medical-light to-white p-6 pb-8">
        <div className="flex items-center justify-between mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleBack}
            className="w-10 h-10 bg-white/80 rounded-full shadow-sm"
          >
            <ArrowLeft className="h-5 w-5 text-gray-600" />
          </Button>
          <div className="flex space-x-2">
            <Button
              variant="ghost"
              size="icon"
              className="w-10 h-10 bg-white/80 rounded-full shadow-sm"
            >
              <Heart className="h-5 w-5 text-gray-600" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="w-10 h-10 bg-white/80 rounded-full shadow-sm"
            >
              <Share className="h-5 w-5 text-gray-600" />
            </Button>
          </div>
        </div>
        
        <div className="text-center">
          <img 
            src={doctor.profileImageUrl || "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300"} 
            alt={`Dr. ${doctor.firstName} ${doctor.lastName}`} 
            className="w-24 h-24 rounded-2xl mx-auto mb-4 object-cover shadow-lg" 
          />
          <h2 className="text-2xl font-bold text-gray-900">
            Dr. {doctor.firstName} {doctor.lastName}
          </h2>
          <p className="text-medical-gray mb-2">{doctor.specialty}</p>
          <div className="flex items-center justify-center space-x-4 text-sm">
            <div className="flex items-center">
              <Star className="h-4 w-4 text-yellow-400 mr-1 fill-current" />
              <span className="font-medium">{doctor.rating}</span>
              <span className="text-gray-500 ml-1">({doctor.reviewCount} reviews)</span>
            </div>
            <div className="flex items-center text-gray-500">
              <MapPin className="h-4 w-4 mr-1" />
              <span>{doctor.distance}km away</span>
            </div>
          </div>
        </div>
      </div>

      <div className="px-6 -mt-4">
        {/* Quick stats */}
        <Card className="shadow-sm border border-gray-100 mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-3 divide-x divide-gray-200">
              <div className="text-center">
                <p className="text-2xl font-bold text-medical-blue">{doctor.yearsExperience}+</p>
                <p className="text-xs text-gray-500">Years Experience</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-trust-green">500+</p>
                <p className="text-xs text-gray-500">Patients Treated</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-purple-600">98%</p>
                <p className="text-xs text-gray-500">Success Rate</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Available Times */}
        <Card className="shadow-sm border border-gray-100 mb-6">
          <CardContent className="p-5">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Available Times</h3>
            
            <div className="flex space-x-3 mb-4">
              <Button className="bg-medical-blue text-white px-4 py-2 rounded-lg text-sm font-medium">
                Today
              </Button>
              <Button variant="outline" className="px-4 py-2 rounded-lg text-sm font-medium">
                Tomorrow
              </Button>
              <Button variant="outline" className="px-4 py-2 rounded-lg text-sm font-medium">
                This Week
              </Button>
            </div>

            <div className="grid grid-cols-3 gap-3">
              {['9:00 AM', '11:30 AM', '2:30 PM', '4:00 PM', '5:30 PM'].map((time, index) => (
                <Button
                  key={time}
                  variant={index === 0 ? "default" : "outline"}
                  className={`py-3 rounded-lg text-sm font-medium transition-colors ${
                    index === 0 
                      ? 'bg-trust-green text-white hover:bg-green-600' 
                      : 'hover:bg-gray-100'
                  }`}
                >
                  {time}
                </Button>
              ))}
              <Button 
                variant="outline" 
                disabled 
                className="bg-gray-200 text-gray-400 py-3 rounded-lg text-sm font-medium cursor-not-allowed"
              >
                Booked
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* About */}
        <Card className="shadow-sm border border-gray-100 mb-6">
          <CardContent className="p-5">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              About Dr. {doctor.lastName}
            </h3>
            <p className="text-gray-600 text-sm leading-relaxed mb-4">
              {doctor.about || `Dr. ${doctor.firstName} ${doctor.lastName} is a board-certified ${doctor.specialty.toLowerCase()} with over ${doctor.yearsExperience} years of experience.`}
            </p>
            
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Calendar className="h-4 w-4 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium text-sm">{doctor.education || 'Medical School'}</p>
                  <p className="text-xs text-gray-500">MD, {doctor.specialty}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                  <Clock className="h-4 w-4 text-green-600" />
                </div>
                <div>
                  <p className="font-medium text-sm">{doctor.location || 'Medical Center'}</p>
                  <p className="text-xs text-gray-500">Primary Practice</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Reviews */}
        <Card className="shadow-sm border border-gray-100 mb-6">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Patient Reviews</h3>
              <Button variant="link" className="text-medical-blue text-sm font-medium p-0">
                View All
              </Button>
            </div>
            
            <div className="space-y-4">
              {reviews.slice(0, 2).map((review) => (
                <div key={review.id} className="border-b border-gray-100 pb-4 last:border-b-0 last:pb-0">
                  <div className="flex items-center space-x-2 mb-2">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-3 w-3 ${
                            i < review.rating 
                              ? 'text-yellow-400 fill-current' 
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm font-medium">Patient</span>
                    <span className="text-xs text-gray-500">
                      {new Date(review.createdAt!).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{review.comment}</p>
                </div>
              ))}
              
              {reviews.length === 0 && (
                <p className="text-sm text-gray-500">No reviews yet.</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Book Appointment Button */}
        <div className="sticky bottom-0 bg-white p-4 rounded-t-2xl border-t border-gray-200 -mx-6 mb-6">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-sm text-gray-500">Consultation Fee</p>
              <p className="text-2xl font-bold text-gray-900">${doctor.consultationFee}</p>
            </div>
            <Button 
              onClick={handleBookAppointment}
              className="bg-medical-blue text-white px-8 py-3 rounded-xl font-medium hover:bg-medical-deep transition-colors shadow-lg"
            >
              Book Appointment
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
