import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, CloudUpload } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { Doctor } from "@shared/schema";

const bookingSchema = z.object({
  reason: z.string().min(10, "Please provide more details about your visit"),
  phone: z.string().optional(),
  email: z.string().email().optional(),
  emergencyContactName: z.string().optional(),
  emergencyContactPhone: z.string().optional(),
  appointmentDate: z.string(),
  type: z.enum(['in-person', 'video']),
});

type BookingForm = z.infer<typeof bookingSchema>;

export default function BookAppointment() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const doctorId = parseInt(id!);

  const { data: doctor, isLoading } = useQuery<Doctor>({
    queryKey: [`/api/doctors/${doctorId}`],
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm<BookingForm>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      phone: user?.phone || '',
      email: user?.email || '',
      emergencyContactName: user?.emergencyContactName || '',
      emergencyContactPhone: user?.emergencyContactPhone || '',
      appointmentDate: new Date().toISOString(),
      type: 'in-person',
    },
  });

  const createAppointment = useMutation({
    mutationFn: async (data: BookingForm) => {
      const response = await apiRequest('POST', '/api/appointments', {
        doctorId,
        appointmentDate: data.appointmentDate,
        type: data.type,
        reason: data.reason,
        notes: `Phone: ${data.phone}, Email: ${data.email}, Emergency Contact: ${data.emergencyContactName} (${data.emergencyContactPhone})`,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Appointment Booked!",
        description: "Your appointment has been successfully booked.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
      setLocation('/appointments');
    },
    onError: (error: Error) => {
      toast({
        title: "Booking Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleBack = () => {
    setLocation(`/doctors/${doctorId}`);
  };

  const onSubmit = (data: BookingForm) => {
    createAppointment.mutate(data);
  };

  if (isLoading || !doctor) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleBack}
            className="w-10 h-10 bg-gray-100 rounded-full"
          >
            <ArrowLeft className="h-5 w-5 text-gray-600" />
          </Button>
          <h2 className="text-xl font-semibold text-gray-900">Book Appointment</h2>
          <div className="w-10"></div>
        </div>
        <div className="space-y-4">
          <div className="h-24 bg-gray-200 rounded-2xl animate-pulse" />
          <div className="h-32 bg-gray-200 rounded-2xl animate-pulse" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 pb-24">
      <div className="flex items-center justify-between mb-6">
        <Button
          variant="ghost"
          size="icon"
          onClick={handleBack}
          className="w-10 h-10 bg-gray-100 rounded-full"
        >
          <ArrowLeft className="h-5 w-5 text-gray-600" />
        </Button>
        <h2 className="text-xl font-semibold text-gray-900">Book Appointment</h2>
        <div className="w-10"></div>
      </div>

      {/* Doctor Summary */}
      <Card className="shadow-sm border border-gray-100 mb-6">
        <CardContent className="p-4">
          <div className="flex space-x-4">
            <img 
              src={doctor.profileImageUrl || "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200"} 
              alt={`Dr. ${doctor.firstName} ${doctor.lastName}`} 
              className="w-16 h-16 rounded-xl object-cover" 
            />
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900">
                Dr. {doctor.firstName} {doctor.lastName}
              </h3>
              <p className="text-sm text-medical-gray">{doctor.specialty}</p>
              <p className="text-sm text-gray-600 mt-1">Today, 9:00 AM • In-Person</p>
              <p className="text-sm font-medium text-medical-blue mt-1">
                ${doctor.consultationFee} Consultation Fee
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Booking Form */}
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div>
          <Label htmlFor="reason" className="text-sm font-medium text-gray-700 mb-3">
            Reason for Visit
          </Label>
          <Textarea
            id="reason"
            {...register('reason')}
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-medical-blue focus:border-transparent resize-none"
            rows={4}
            placeholder="Please describe your symptoms or reason for the appointment..."
          />
          {errors.reason && (
            <p className="text-sm text-red-600 mt-1">{errors.reason.message}</p>
          )}
        </div>

        <div>
          <Label className="block text-sm font-medium text-gray-700 mb-3">
            Upload Medical Documents (Optional)
          </Label>
          <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-medical-blue transition-colors cursor-pointer">
            <CloudUpload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
            <p className="text-sm text-gray-600">Tap to upload photos or documents</p>
            <p className="text-xs text-gray-500 mt-1">PNG, JPG, PDF up to 10MB</p>
          </div>
        </div>

        <div>
          <Label className="block text-sm font-medium text-gray-700 mb-3">
            Contact Information
          </Label>
          <div className="space-y-3">
            <Input
              type="tel"
              {...register('phone')}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-medical-blue focus:border-transparent"
              placeholder="Phone number"
            />
            <Input
              type="email"
              {...register('email')}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-medical-blue focus:border-transparent"
              placeholder="Email address"
            />
          </div>
        </div>

        <div>
          <Label className="block text-sm font-medium text-gray-700 mb-3">
            Emergency Contact
          </Label>
          <div className="space-y-3">
            <Input
              type="text"
              {...register('emergencyContactName')}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-medical-blue focus:border-transparent"
              placeholder="Emergency contact name"
            />
            <Input
              type="tel"
              {...register('emergencyContactPhone')}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-medical-blue focus:border-transparent"
              placeholder="Emergency contact phone"
            />
          </div>
        </div>

        {/* Payment Section */}
        <Card className="bg-gray-50">
          <CardContent className="p-4">
            <h3 className="font-medium text-gray-900 mb-3">Payment Summary</h3>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Consultation Fee</span>
                <span className="font-medium">${doctor.consultationFee}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Platform Fee</span>
                <span className="font-medium">$5.00</span>
              </div>
              <div className="border-t border-gray-200 pt-2 mt-2">
                <div className="flex justify-between font-semibold">
                  <span>Total</span>
                  <span className="text-medical-blue">
                    ${(parseFloat(doctor.consultationFee.toString()) + 5).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Button 
          type="submit"
          disabled={createAppointment.isPending}
          className="w-full bg-medical-blue text-white py-4 rounded-xl font-semibold hover:bg-medical-deep transition-colors shadow-lg"
        >
          {createAppointment.isPending ? "Booking..." : "Confirm & Book Appointment"}
        </Button>

        <p className="text-xs text-gray-500 text-center leading-relaxed">
          By booking this appointment, you agree to our Terms of Service and Privacy Policy. 
          You will receive a confirmation email with appointment details.
        </p>
      </form>
    </div>
  );
}
