import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { Link, useLocation } from "wouter";
import BottomNav from "@/components/BottomNav";
import { 
  Search, 
  User, 
  CalendarCheck, 
  Video,
  Heart,
  Baby,
  Bone,
  Hand
} from "lucide-react";

const specialties = [
  { id: 'dermatology', name: 'Dermatology', description: 'Skin conditions', icon: Hand, color: 'pink' },
  { id: 'cardiology', name: 'Cardiology', description: 'Heart health', icon: Heart, color: 'red' },
  { id: 'pediatrics', name: 'Pediatrics', description: "Children's health", icon: Baby, color: 'blue' },
  { id: 'orthopedics', name: 'Orthopedics', description: 'Bone & joint', icon: Bone, color: 'green' },
];

export default function Home() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [consultationType, setConsultationType] = useState("in-person");

  const handleSearch = () => {
    const params = new URLSearchParams();
    if (searchTerm) params.append('search', searchTerm);
    if (consultationType) params.append('type', consultationType);
    setLocation(`/doctors?${params.toString()}`);
  };

  const handleSpecialtyClick = (specialty: string) => {
    setLocation(`/doctors?specialty=${specialty}`);
  };

  return (
    <div className="pb-20 bg-medical-blue-light min-h-screen">
      {/* Header */}
      <div className="bg-gradient-to-br from-medical-blue to-medical-accent text-white p-6 rounded-b-3xl shadow-lg">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-semibold">
              Hello, {(user as any)?.firstName || 'Patient'}
            </h2>
            <p className="text-blue-100">How can we help you today?</p>
          </div>
          <Link href="/profile">
            <Button 
              variant="ghost" 
              size="icon"
              className="w-10 h-10 bg-white/20 rounded-full hover:bg-white/30"
            >
              <User className="text-white h-5 w-5" />
            </Button>
          </Link>
        </div>

        <Card className="bg-white/90 backdrop-blur-sm border-0">
          <CardContent className="p-4">
            <p className="text-medical-blue font-medium mb-3">Find a Doctor</p>
            <div className="space-y-3">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Specialty, condition, doctor name..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-medical-blue focus:border-transparent"
                />
              </div>
              <div className="flex space-x-2">
                <Select value={consultationType} onValueChange={setConsultationType}>
                  <SelectTrigger className="flex-1 border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-medical-blue">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="in-person">In-Person</SelectItem>
                    <SelectItem value="video">Video Call</SelectItem>
                    <SelectItem value="both">Both</SelectItem>
                  </SelectContent>
                </Select>
                <Button 
                  onClick={handleSearch}
                  className="bg-medical-blue text-white px-6 py-2 rounded-lg font-medium hover:bg-medical-deep transition-colors"
                >
                  Search
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="p-6">
        <div className="grid grid-cols-2 gap-4 mb-6">
          <Link href="/appointments">
            <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer border-0 shadow-md hover:scale-[1.02]">
              <CardContent className="p-5">
                <div className="w-14 h-14 bg-gradient-to-br from-medical-success to-medical-success/80 rounded-2xl flex items-center justify-center mb-4 shadow-sm">
                  <CalendarCheck className="text-white h-7 w-7" />
                </div>
                <p className="font-semibold medical-text text-base">My Appointments</p>
                <p className="text-sm medical-text-light">View & manage</p>
              </CardContent>
            </Card>
          </Link>
          <Link href="/consultations">
            <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer border-0 shadow-md hover:scale-[1.02]">
              <CardContent className="p-5">
                <div className="w-14 h-14 bg-gradient-to-br from-medical-accent to-medical-accent/80 rounded-2xl flex items-center justify-center mb-4 shadow-sm">
                  <Video className="text-white h-7 w-7" />
                </div>
                <p className="font-semibold medical-text text-base">Consultations</p>
                <p className="text-sm medical-text-light">Past & upcoming</p>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Popular Specialties */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold medical-text mb-4">Popular Specialties</h3>
          <div className="grid grid-cols-2 gap-4">
            {specialties.map((specialty) => {
              const IconComponent = specialty.icon;
              const colorClasses = {
                pink: 'from-pink-400 to-pink-500',
                red: 'from-red-400 to-red-500', 
                blue: 'from-blue-400 to-blue-500',
                green: 'from-green-400 to-green-500',
              };
              
              return (
                <Button
                  key={specialty.id}
                  variant="ghost"
                  onClick={() => handleSpecialtyClick(specialty.id)}
                  className="h-auto p-0 hover:scale-[1.02] transition-transform"
                >
                  <Card className="w-full hover:shadow-md transition-shadow">
                    <CardContent className="p-3">
                      <div className="flex items-center space-x-3">
                        <div className={`w-12 h-12 bg-gradient-to-br ${colorClasses[specialty.color as keyof typeof colorClasses]} rounded-2xl flex items-center justify-center shadow-sm`}>
                          <IconComponent className="h-6 w-6 text-white" />
                        </div>
                        <div className="text-left">
                          <p className="font-semibold medical-text text-sm">{specialty.name}</p>
                          <p className="text-xs medical-text-light">{specialty.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Button>
              );
            })}
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
