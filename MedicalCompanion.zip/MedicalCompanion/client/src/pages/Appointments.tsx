import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import AppointmentCard from "@/components/AppointmentCard";
import BottomNav from "@/components/BottomNav";
import { Appointment } from "@shared/schema";

export default function Appointments() {
  const [activeTab, setActiveTab] = useState<'upcoming' | 'past' | 'cancelled'>('upcoming');

  const { data: appointments = [], isLoading } = useQuery<Appointment[]>({
    queryKey: ['/api/appointments', { status: activeTab }],
  });

  return (
    <div className="pb-20">
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">My Appointments</h2>
          <Button
            variant="ghost"
            size="icon"
            className="w-10 h-10 bg-gray-100 rounded-full"
          >
            <Search className="h-5 w-5 text-gray-600" />
          </Button>
        </div>

        {/* Filter Tabs */}
        <div className="flex space-x-1 mb-6 bg-gray-100 rounded-xl p-1">
          <Button
            variant={activeTab === 'upcoming' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('upcoming')}
            className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium ${
              activeTab === 'upcoming' 
                ? 'bg-white text-medical-blue shadow-sm' 
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Upcoming
          </Button>
          <Button
            variant={activeTab === 'past' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('past')}
            className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium ${
              activeTab === 'past' 
                ? 'bg-white text-medical-blue shadow-sm' 
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Past
          </Button>
          <Button
            variant={activeTab === 'cancelled' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('cancelled')}
            className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium ${
              activeTab === 'cancelled' 
                ? 'bg-white text-medical-blue shadow-sm' 
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Cancelled
          </Button>
        </div>

        {/* Appointments List */}
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-gray-200 rounded-2xl h-32 animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {appointments.map((appointment) => (
              <AppointmentCard key={appointment.id} appointment={appointment} />
            ))}
            
            {appointments.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-500">
                  No {activeTab} appointments found.
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}
