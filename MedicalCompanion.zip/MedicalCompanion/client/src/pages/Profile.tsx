import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import BottomNav from "@/components/BottomNav";
import { 
  User, 
  FileText, 
  Shield, 
  CreditCard, 
  Bell, 
  Headphones,
  ChevronRight,
  CheckCircle
} from "lucide-react";

const menuItems = [
  {
    icon: User,
    title: "Personal Information",
    description: "Manage your personal details",
    color: "blue",
    href: "/profile/personal",
  },
  {
    icon: FileText,
    title: "Medical History",
    description: "View your medical records",
    color: "green",
    href: "/profile/medical-history",
  },
  {
    icon: Shield,
    title: "Insurance",
    description: "Manage insurance information",
    color: "purple",
    href: "/profile/insurance",
  },
  {
    icon: CreditCard,
    title: "Payment Methods",
    description: "Manage payment options",
    color: "yellow",
    href: "/profile/payments",
  },
  {
    icon: Bell,
    title: "Notifications",
    description: "Customize your alerts",
    color: "indigo",
    href: "/profile/notifications",
  },
  {
    icon: Headphones,
    title: "Help & Support",
    description: "Get help or contact us",
    color: "pink",
    href: "/profile/support",
  },
];

export default function Profile() {
  const { user } = useAuth();

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const getColorClasses = (color: string) => {
    const classes = {
      blue: 'bg-blue-100 text-blue-600',
      green: 'bg-green-100 text-green-600',
      purple: 'bg-purple-100 text-purple-600',
      yellow: 'bg-yellow-100 text-yellow-600',
      indigo: 'bg-indigo-100 text-indigo-600',
      pink: 'bg-pink-100 text-pink-600',
    };
    return classes[color as keyof typeof classes] || classes.blue;
  };

  return (
    <div className="pb-20">
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Profile</h2>
          <Button variant="link" className="text-medical-blue font-medium p-0">
            Edit
          </Button>
        </div>

        {/* Profile Header */}
        <div className="text-center mb-8">
          <img 
            src={user?.profileImageUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300"} 
            alt={user?.firstName || 'Patient'} 
            className="w-24 h-24 rounded-2xl mx-auto mb-4 object-cover shadow-lg" 
          />
          <h3 className="text-xl font-semibold text-gray-900">
            {user?.firstName} {user?.lastName}
          </h3>
          <p className="text-medical-gray">{user?.email}</p>
          <div className="flex items-center justify-center space-x-2 mt-2">
            <CheckCircle className="h-4 w-4 text-trust-green" />
            <span className="text-sm text-trust-green font-medium">Verified Account</span>
          </div>
        </div>

        {/* Profile Stats */}
        <Card className="shadow-sm border border-gray-100 mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-3 divide-x divide-gray-200">
              <div className="text-center">
                <p className="text-2xl font-bold text-medical-blue">12</p>
                <p className="text-xs text-gray-500">Appointments</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-trust-green">8</p>
                <p className="text-xs text-gray-500">Consultations</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-purple-600">4</p>
                <p className="text-xs text-gray-500">Doctors</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Menu Items */}
        <div className="space-y-4">
          {menuItems.map((item) => {
            const IconComponent = item.icon;
            return (
              <Button
                key={item.title}
                variant="ghost"
                className="w-full h-auto p-0"
                onClick={() => {
                  // For demo purposes, just show alert
                  alert(`Navigate to ${item.title}`);
                }}
              >
                <Card className="w-full hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${getColorClasses(item.color)}`}>
                        <IconComponent className="h-6 w-6" />
                      </div>
                      <div className="flex-1 text-left">
                        <p className="font-medium text-gray-900">{item.title}</p>
                        <p className="text-sm text-gray-500">{item.description}</p>
                      </div>
                      <ChevronRight className="h-5 w-5 text-gray-400" />
                    </div>
                  </CardContent>
                </Card>
              </Button>
            );
          })}
        </div>

        <div className="mt-8">
          <Button 
            onClick={handleLogout}
            variant="destructive"
            className="w-full bg-red-50 text-red-600 py-3 rounded-xl font-medium hover:bg-red-100 transition-colors border-0"
          >
            Sign Out
          </Button>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
