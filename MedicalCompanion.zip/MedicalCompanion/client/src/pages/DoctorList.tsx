import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Filter } from "lucide-react";
import DoctorCard from "@/components/DoctorCard";
import { Doctor } from "@shared/schema";

export default function DoctorList() {
  const [, setLocation] = useLocation();
  const params = new URLSearchParams(window.location.search);
  const specialty = params.get('specialty');
  const search = params.get('search');

  const { data: doctors = [], isLoading } = useQuery<Doctor[]>({
    queryKey: ['/api/doctors', { specialty, search }],
  });

  const handleBack = () => {
    setLocation('/');
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleBack}
            className="w-10 h-10 bg-gray-100 rounded-full"
          >
            <ArrowLeft className="h-5 w-5 text-gray-600" />
          </Button>
          <h2 className="text-xl font-semibold text-gray-900">Doctors</h2>
          <Button
            variant="ghost"
            size="icon"
            className="w-10 h-10 bg-gray-100 rounded-full"
          >
            <Filter className="h-5 w-5 text-gray-600" />
          </Button>
        </div>
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="bg-gray-200 rounded-2xl h-32 animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <Button
          variant="ghost"
          size="icon"
          onClick={handleBack}
          className="w-10 h-10 bg-gray-100 rounded-full"
        >
          <ArrowLeft className="h-5 w-5 text-gray-600" />
        </Button>
        <h2 className="text-xl font-semibold text-gray-900">
          {specialty ? specialty.charAt(0).toUpperCase() + specialty.slice(1) : 'Doctors'}
        </h2>
        <Button
          variant="ghost"
          size="icon"
          className="w-10 h-10 bg-gray-100 rounded-full"
        >
          <Filter className="h-5 w-5 text-gray-600" />
        </Button>
      </div>

      <div className="mb-4">
        <p className="text-sm text-gray-600">{doctors.length} doctors available</p>
      </div>

      <div className="space-y-4">
        {doctors.map((doctor) => (
          <DoctorCard key={doctor.id} doctor={doctor} />
        ))}
      </div>

      {doctors.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">No doctors found matching your criteria.</p>
          <Button 
            onClick={handleBack}
            className="mt-4 bg-medical-blue text-white hover:bg-medical-deep"
          >
            Search Again
          </Button>
        </div>
      )}
    </div>
  );
}
