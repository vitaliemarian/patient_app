import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Landing() {
  const [eenstaId, setEenstaId] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gray-50 relative overflow-hidden">
      {/* Purple curved background */}
      <div className="absolute top-0 left-0 w-full h-80 overflow-hidden">
        <svg
          className="w-full h-full"
          viewBox="0 0 1200 320"
          preserveAspectRatio="none"
        >
          <defs>
            <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#A855F7" />
              <stop offset="50%" stopColor="#9333EA" />
              <stop offset="100%" stopColor="#7C3AED" />
            </linearGradient>
          </defs>
          <path d="M0,0 L1200,0 L1200,200 C900,280 300,280 0,200 Z" fill="url(#grad)" />
        </svg>
        
        <div className="absolute inset-0 flex items-center justify-center">
          <h1 className="text-white text-2xl font-light tracking-wider">
            eensta doctor
          </h1>
        </div>
      </div>

      {/* Login form container */}
      <div className="relative z-10 pt-72 px-8 pb-8">
        <div className="max-w-sm mx-auto">
          <div className="space-y-4">
            {/* Eensta ID Input */}
            <div>
              <Input
                type="text"
                placeholder="Eensta ID"
                value={eenstaId}
                onChange={(e) => setEenstaId(e.target.value)}
                className="w-full h-16 px-5 bg-white border border-gray-200 rounded-2xl text-gray-800 placeholder-gray-400 text-lg focus:outline-none focus:ring-0 focus:border-purple-400 shadow-sm"
              />
            </div>

            {/* Password Input */}
            <div>
              <Input
                type="password"
                placeholder="Parola"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full h-16 px-5 bg-white border border-gray-200 rounded-2xl text-gray-800 placeholder-gray-400 text-lg focus:outline-none focus:ring-0 focus:border-purple-400 shadow-sm"
              />
            </div>

            {/* Login Button */}
            <Button 
              onClick={handleLogin}
              className="w-full h-16 text-white font-medium text-lg rounded-2xl transition-all duration-200 shadow-md hover:shadow-lg mt-6"
              style={{
                background: 'linear-gradient(135deg, #A855F7 0%, #9333EA 50%, #7C3AED 100%)'
              }}
            >
              Loghează-te
            </Button>

            {/* Sign up link */}
            <div className="text-center pt-6">
              <p className="text-gray-500 text-base">
                Nu ai cont?{" "}
                <Button 
                  variant="link" 
                  className="text-purple-600 font-medium hover:underline p-0 text-base"
                  onClick={handleLogin}
                >
                  Înscrie-te
                </Button>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
