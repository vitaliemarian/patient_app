import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Video, Plus, Send } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { Message } from "@shared/schema";

export default function Chat() {
  const { conversationId } = useParams();
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [messageText, setMessageText] = useState("");

  const { data: messages = [], isLoading } = useQuery<Message[]>({
    queryKey: [`/api/conversations/${conversationId}/messages`],
  });

  const sendMessage = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest('POST', `/api/conversations/${conversationId}/messages`, {
        content,
        messageType: 'text',
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: [`/api/conversations/${conversationId}/messages`] 
      });
      setMessageText("");
    },
  });

  const handleBack = () => {
    setLocation('/messages');
  };

  const handleSendMessage = () => {
    if (messageText.trim()) {
      sendMessage.mutate(messageText.trim());
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="flex flex-col h-screen">
      {/* Chat Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleBack}
            className="w-8 h-8 bg-gray-100 rounded-full"
          >
            <ArrowLeft className="h-4 w-4 text-gray-600" />
          </Button>
          <img 
            src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" 
            alt="Dr. Sarah Mitchell" 
            className="w-10 h-10 rounded-lg object-cover" 
          />
          <div className="flex-1">
            <h3 className="font-medium text-gray-900">Dr. Sarah Mitchell</h3>
            <p className="text-sm text-green-600">Online now</p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="w-8 h-8 bg-gray-100 rounded-full"
          >
            <Video className="h-4 w-4 text-gray-600" />
          </Button>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex space-x-3">
                <div className="w-8 h-8 bg-gray-200 rounded-lg animate-pulse" />
                <div className="bg-gray-200 rounded-2xl h-16 w-3/4 animate-pulse" />
              </div>
            ))}
          </div>
        ) : (
          messages.map((message) => (
            <div 
              key={message.id} 
              className={`flex items-start space-x-3 ${
                message.senderId === user?.id ? 'justify-end' : ''
              }`}
            >
              {message.senderId !== user?.id && (
                <img 
                  src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" 
                  alt="Doctor" 
                  className="w-8 h-8 rounded-lg object-cover" 
                />
              )}
              <div 
                className={`rounded-2xl p-3 max-w-xs shadow-sm ${
                  message.senderId === user?.id
                    ? 'bg-medical-blue text-white rounded-tr-lg'
                    : 'bg-white text-gray-900 rounded-tl-lg'
                }`}
              >
                <p className="text-sm">{message.content}</p>
                <p className={`text-xs mt-2 ${
                  message.senderId === user?.id ? 'text-blue-100' : 'text-gray-500'
                }`}>
                  {new Date(message.createdAt!).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </p>
              </div>
            </div>
          ))
        )}

        {messages.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <p className="text-gray-500">No messages yet.</p>
            <p className="text-sm text-gray-400 mt-2">
              Start a conversation with your doctor.
            </p>
          </div>
        )}
      </div>

      {/* Message Input */}
      <div className="bg-white border-t border-gray-200 p-4">
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="icon"
            className="w-10 h-10 bg-gray-100 rounded-full"
          >
            <Plus className="h-5 w-5 text-gray-600" />
          </Button>
          <div className="flex-1 relative">
            <Input
              type="text"
              placeholder="Type your message..."
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              onKeyPress={handleKeyPress}
              className="w-full px-4 py-2 border border-gray-300 rounded-full focus:ring-2 focus:ring-medical-blue focus:border-transparent pr-12"
            />
            <Button
              onClick={handleSendMessage}
              disabled={!messageText.trim() || sendMessage.isPending}
              size="icon"
              className="absolute right-2 top-2 w-6 h-6 bg-medical-blue rounded-full hover:bg-medical-deep"
            >
              <Send className="h-3 w-3 text-white" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
